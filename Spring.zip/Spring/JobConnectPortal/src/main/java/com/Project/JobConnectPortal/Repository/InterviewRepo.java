package com.Project.JobConnectPortal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Project.JobConnectPortal.Model.Interview;

public interface InterviewRepo extends JpaRepository<Interview, Integer> {

}
