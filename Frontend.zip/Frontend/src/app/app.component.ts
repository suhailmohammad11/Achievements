import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { JobSearchService } from './job-search.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title // Password validation
    (title: any) {
      throw new Error('Method not implemented.');
  }
  loginForm: FormGroup;
    strLoginMsg: string = '';
  
    constructor(private fb: FormBuilder, private router: Router, private userService: JobSearchService) {
      this.loginForm = this.fb.group({
        email: ['', [Validators.required, Validators.email]],  // Email validation
        password: ['', Validators.required],                    // Password validation
        type: ['', Validators.required]                          // User type validation
      });
      this.registerForm = this.fb.group({
        userName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required],
        confirmPassword: ['', Validators.required],
        type: ['', Validators.required]  // Add the 'type' field with validation
      });
  
      // Watch for changes in the password and confirm password fields
      this.registerForm.valueChanges.subscribe(() => {
        this.checkPasswordMatch();
      });
    }
    type='';
    ngOnInit(): void {}
    toggleLoginBtn = false
    navigatePage = '' 
    toggle = false
    togg = false;
    loged(){
      this.toggleLoginBtn=true;
    }

    log(){
      this.toggleLoginBtn=true;
      this.router.navigate(['/']);
    }
    sign(){
      this.togg=true;
      this.toggleLoginBtn=false;
    }
    loginFormSubmit() {
      if (this.loginForm.valid) {
        const loginData = this.loginForm.value;
        // Call the login API service
        this.type=this.loginForm.value.type;
        this.userService.login(loginData).subscribe(
          (response: any) => {
            // Check the message from the server response
            alert(response.message)
            if (response.message === 'Login successful' && this.loginForm.value.type=='admin') {
              this.toggleLoginBtn = false;
              alert(this.loginForm.value.type)
                this.router.navigate(['/admin'])
            }else if(response.message === 'Login successful' && this.loginForm.value.type=='employer'){
              this.toggleLoginBtn = false;
              alert(this.loginForm.value.type)
                this.router.navigate(['/employeer'])
            }
            else if(response.message === 'Login successful' && this.loginForm.value.type=='jobseeker'){
              this.toggleLoginBtn = false;
              alert(this.loginForm.value.type)
                this.router.navigate(['/jobseeker'])
            } 
             else {
              this.strLoginMsg = response.message;  // Show error message from API
            }
          },
          (error) => {
            // Handle error if the backend request fails
            console.error('Error during login:', error);
            this.strLoginMsg = 'Login failed: Invalid email, password, type, or status.';
          }
        );
      } else {
        this.strLoginMsg = 'Please fill out the form correctly.';
      }
    }
    registerForm: FormGroup;
  passwordMismatch: boolean = false;

  // Check if password and confirm password match
  checkPasswordMatch() {
    const password = this.registerForm.get('password')?.value;
    const confirmPassword = this.registerForm.get('confirmPassword')?.value;
    this.passwordMismatch = password !== confirmPassword;
  }

  // Submit registration
  onRegisterSubmit() {
    if (this.registerForm.valid && !this.passwordMismatch) {
      const user = this.registerForm.value; // Include the 'type' field in the submitted data
      this.userService.register(user).subscribe(
        response => {
          console.log('Registration Successful:', response);
          alert('Registeration sucessful');
    
          this.router.navigate(['/login']);
        },
        error => {
          console.log('Error:', error);
          // Handle error
        }
      );
    }
  }

}
