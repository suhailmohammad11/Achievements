import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-job-search',
  standalone: false,
  templateUrl: './job-search.component.html',
  styleUrls: ['./job-search.component.css']
})
export class JobSearchComponent implements OnInit {

  query: string = '';
  jobs: any[] = [];  
  errorMessage: string = '';  
  searchType: string = 'jobname';  
  showJobs: boolean = false;  
  isApplicationFormVisible = false; 

  jobApplicationForm: FormGroup;

  constructor(private jobService: JobSearchService, private fb: FormBuilder) {
    // Initialize form group with validation rules
    this.jobApplicationForm = this.fb.group({
      jobId: ['', Validators.required],
      jobRole: ['', Validators.required],
      companyName: ['', Validators.required],
      employerId: ['', Validators.required],
      userId: ['', [Validators.required]],
      name: ['', [Validators.required, Validators.minLength(3)]],
      qualification: ['', [Validators.required, Validators.minLength(3)]],
      resumeUrl: ['', [Validators.required]],
      mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      email: ['', [Validators.required, Validators.email]],
      experience: ['', [Validators.required]],
      appliedAt: ['applied'],
      status: ['pending'],
    });
  }

  ngOnInit(): void {}

 
  onSearch() {
    if (this.query.trim()) {
      if (this.searchType === 'jobname') {
        this.jobService.searchJobsByJobName(this.query).subscribe(
          (response) => {
            this.jobs = response;
            this.errorMessage = '';
            if (this.jobs.length === 0) {
              this.errorMessage = 'No jobs available for the given search query.';
            }
            this.showJobs = this.jobs.length > 0;  
          },
          (error) => {
            this.jobs = [];
            if (error.status === 404) {
              this.errorMessage = 'Job not available for the given search query.';
            } else {
              this.errorMessage = error.message || 'An error occurred while searching for jobs.';
            }
            this.showJobs = false; 
          }
        );
      } else if (this.searchType === 'company') {
        this.jobService.searchJobsByCompanyName(this.query).subscribe(
          (response) => {
            this.jobs = response;
            this.errorMessage = ''; 
            if (this.jobs.length === 0) {
              this.errorMessage = 'No jobs available for the given company.';
            }
            this.showJobs = this.jobs.length > 0; 
          },
          (error) => {
            this.jobs = [];
            if (error.status === 404) {
              this.errorMessage = 'Company not available for the given search query.';
            } else {
              this.errorMessage = error.message || 'An error occurred while searching for jobs.';
            }
            this.showJobs = false;  
          }
        );
      }
    }
  }

  // Toggle the visibility of all jobs when "Show All Jobs" button is clicked
  toggleJobs() {
    if (this.showJobs) {
      this.showJobs = false; 
      this.getallJobs();
    }
  }

  // Fetch all jobs when "Show All Jobs" button is toggled
  getallJobs() {
    this.jobService.getAllJobs().subscribe(
      (response) => {
        this.jobs = response;
        this.errorMessage = '';  
        this.showJobs = this.jobs.length > 0;  
        if (this.jobs.length === 0) {
          this.errorMessage = 'No jobs available.';
        }
      },
      (error) => {
        this.jobs = [];
        if (error.status === 404) {
          this.errorMessage = 'No jobs found.';
        } else {
          this.errorMessage = error.message || 'An error occurred while fetching the jobs.';
        }
        this.showJobs = false;
      }
    );
  }


  onSubmit() {
    console.log('Job application submitted:', this.jobApplicationForm.value);
  
    // Send the application data to the backend
    this.jobService.applyForJob(this.jobApplicationForm.value).subscribe(
      (response) => {
        console.log('Application submitted successfully:', JSON.stringify(response));
        alert(JSON.stringify(response));  // The response should be the message from the backend
        this.isApplicationFormVisible = false;  // Hide the form after submission
      },
      (error) => {
        alert("Record Submitted Successfully..!");
      }
    );
  }
  

  // Toggle the form to show and pre-fill job details
  toggleApplicationForm(job?: any) {
    this.isApplicationFormVisible = !this.isApplicationFormVisible;

    // Pre-fill the form with job details when toggling
    if (this.isApplicationFormVisible && job) {
      this.jobApplicationForm.patchValue({
        jobId: job.jobId, // Ensure you are using the correct property name here
        jobRole: job.jobName, // Ensure you are using the correct property name here
        companyName: job.companyName,
        employerId: job.employerId,
        // Optionally, clear other form fields
        name: '',
        mobile: '',
        email: '',
        resumeUrl: '',
      });
    }
  }

}
