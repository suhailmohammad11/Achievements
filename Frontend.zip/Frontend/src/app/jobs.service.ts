import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Job } from './job';
import { HttpClient } from '@angular/common/http';
import { Application } from './application';
import { Interview } from './interview';

@Injectable({
  providedIn: 'root'
})
export class JobsService {

  applications:Application[]=[];
  interviews:Interview[]=[];
 
 
  constructor(private http:HttpClient) { }
  strUrl = "http://localhost:8091/";
  getAllJobs():Observable<any>{
    let strUrlGetJobs = this.strUrl + "api/employer/jobs";
    return this.http.get<any>(strUrlGetJobs);
  }
  insertJob(job : Job):Observable<any>{
    let strPostJobsURL = this.strUrl+"addJobs";
    console.log(("before insert:"+JSON.stringify(job)))
 
    return this.http.post(strPostJobsURL,job);
  }
  deleteJobRecord(job_id:number) : Observable<string>{
    let strDeleteUrl = this.strUrl+"deleteRecord/"+job_id;
    alert ("job ID:"+job_id);
    return this.http.delete<string> (strDeleteUrl, {responseType:'text' as 'json'}) ;
  }
     
}
