import { Component } from '@angular/core';
import { Interview } from '../interview';
import { Application } from '../application';
import { Job } from '../job';
import { FormBuilder, FormGroup } from '@angular/forms';
import { JobsService } from '../jobs.service';
import { InterviewServiceService } from '../interview-service.service';
import { ApplicationService } from '../application.service';

@Component({
  selector: 'app-employer',
  standalone: false,
  templateUrl: './employer.component.html',
  styleUrl: './employer.component.css'
})
export class EmployerComponent {
  title = 'myapp';
  // showInterviewList = false; // Controls visibility of the interview list
 
  // // Toggle the visibility of the interview list
  // toggleInterviewList(): void {
  //   this.showInterviewList = !this.showInterviewList;
 
   
  // }
  // showApplicationList = false; // Controls visibility of the application list
 
  // //Toggle the visibility of the application list
  // toggleApplicationList(): void {
  //   this.showApplicationList = !this.showApplicationList;
  // }
  // // showJobList = false;
  // // toggleJobList(): void {
  // //   this.showJobList = !this.showJobList;
  // // }
  // showJobList = false;
  // toggleJobList(): void {
  // this.showJobList = !this.showJobList;
  // }
 
 
  JobForm!:FormGroup;
    constructor(private jobService : JobsService,private fb:FormBuilder, private interviewService: InterviewServiceService, private applicationService: ApplicationService){
      this.JobForm=this.fb.group({
        job_id:[''],
        job_name:[''],
        department:[''],
        skills:[''],
        experience:[''],
        job_description:[''],
        salary:[''],
        emp_id:[''],
        post_date:[''],
      })
    }
    bAdd=false;
    strAddNames='';
    addJobList(){
      this.bAdd=true;
      this.strAddNames="Add Record"
    }
    t=false
    t1=false
    t3=false
    AddJobRecord(){
      let job_id = this.JobForm.get('job_id')?.value;
      let job_name = this.JobForm.get('job_name')?.value;
      let department = this.JobForm.get('department')?.value;
      let skills = this.JobForm.get('skills')?.value;
      let experience = this.JobForm.get('experience')?.value;
      let job_description = this.JobForm.get('job_description')?.value;
      let salary = this.JobForm.get('salary')?.value;
      let emp_id = this.JobForm.get('emp_id')?.value;
      let post_date = this.JobForm.get('post_date')?.value;
      console.log ('job_id'+ job_id);
      console.log ('job_name'+ job_name);
      console.log ('department'+department);
      console.log ('skills'+skills);
      console.log ('experience'+experience);
      console.log('job_description'+job_description);
      console.log ('salary'+salary);
      console.log ('emp_id'+emp_id);
      console.log ('post_date'+post_date);
 
      let jobObj=new Job(job_id,job_name,department,skills,experience,job_description,salary,emp_id,post_date);
      this.jobService.insertJob(jobObj).subscribe({
        next :(data) => {
          alert ('Record inserted successfully');
          this.getAllJobsList()
          console.log (JSON.stringify(data))
        },
        error : (err) =>console.log("error while inserting record"+JSON.stringify(err)),
        complete :() => console.log ('Insert operation is successful')
      });
    }
 
    bSearch=true;
    searchForm(){
      if(this.bSearch==true){
        this.bSearch=false;
      }
    }
 
    jobLst : any;
    showTable: boolean = false;
    getAllJobsList(){
      this.t=true
      this.t1=false
      this.t3=false
      this.jobService.getAllJobs().subscribe({
        next :(data) =>{this.jobLst= data;
          this.showTable = true;},
        error :(err) => console.log ("unable to fetch from server"+err),
        complete : () => console.log ("fetching data from server is complete")
      })
    }
 
    EditJobRecord(jobRecord : Job){
      this.bAdd=true;
      this.strAddNames="Edit Record";
      this.JobForm.patchValue({
        job_id:jobRecord.job_id,
        job_name:jobRecord.job_name,
        department:jobRecord.department,
        skills:jobRecord.skills,
        experience:jobRecord.experience,
        job_description:jobRecord.job_description,
        salary:jobRecord.salary,
        emp_id:jobRecord.emp_id,
        post_date:jobRecord.post_date
      });
    }
 
    DeleteJobRecord(job_id:number){
 
      this.jobService.deleteJobRecord(job_id).subscribe({
        next : (data) => {alert ("record deleted successfully");
          this.getAllJobsList();
          console.log (JSON.stringify(data));
        },
        error : (err) => {alert (JSON.stringify(err))},
        complete : () => console.log ('delete operation is complete')
      });
    }
  interviews: Interview[] = [];  
    ngOnInit(): void {
      this.interviews = this.interviewService.getInterviews();
      this.applicationService.getAllApplications().subscribe(applications => {
        console.log(applications); // Check the data structure
        this.applications = applications;
        this.filteredApplications = applications; // Initialize with all applications
      });
    }
 
    // Mark interview as completed
    completeInterview(id: number): void {
      this.interviewService.updateInterviewStatus(id, 'Completed');
    }
 
    // Mark interview as cancelled
    cancelInterview(id: number): void {
      this.interviewService.updateInterviewStatus(id, 'Cancelled');
    }
 
    // Submit feedback for the interview
    // submitFeedback(interview_Id: number,interview_status: string, feedback: string): void{
    //   this.interviewService.updateInterviewStatusAndFeedback(interview_Id,interview_status, feedback);
    // }
     
    submitFeedback(interview_Id: number, interview_status: string, feedback: string): void {
      this.interviewService.updateInterviewStatusAndFeedback(interview_Id, interview_status, feedback)
        .subscribe(
          (response) => {
            // Handle success
            console.log('Feedback submitted successfully:', response);
          },
          (error) => {
            // Handle error
            console.error('Error submitting feedback:', error);
          }
        );
    }
     
    interviewList :any;
    getInterviewList(){
      this.t=false
      this.t1=true
      this.t3=false
      this.interviewService.getAllInterviews().subscribe({
        next :(data) =>{this.interviewList=data;},
        error:(err) =>alert(err),
        complete:()=> console.log("fetching done")
 
        })
    }
 
    applications: Application[] = [];
      filteredApplications: Application[] = [];
      filterQualifications: string = ''; // Filter for qualifications
      filterExperience: string = '';
   

      applyFilter(): void {
        // Call the service's filteredApplications method to get the filtered results
        this.filteredApplications = this.applicationService.filteredApplications(this.filterQualifications, this.filterExperience);
      }
     
     
      private interview:Interview[]=[];
     
      // Approve the application and schedule an interview
      approve(application_id: number): void {
        this.applicationService.updateApplicationStatus(application_id, 'Approved');
        // After approval, automatically schedule an interview
        const application = this.applications.find(app => app.applicationId === application_id);
        if (application) {
          const interview: Interview = {
            interview_Id: this.interviewService.getInterviews().length + 1,
            interview_date: new Date(),
            applicationId: application.applicationId,
            userId: application.userId,
            name: application.name,
            interview_status: 'Scheduled',
            feedback: '' // No feedback yet
          };
        //  this.interviewService.scheduleInterview(interview);
          this.interviewService.saveInterview(interview).subscribe((response: Interview) => {
            // Optionally, you can handle the response here if you need to update the UI with the newly added interview
            console.log('Interview successfully scheduled:', response);
          }, error => {
            console.error('Error scheduling interview:', error);
          });
        }
      }
     
      // Reject the application
      reject(application_id: number): void {
        this.applicationService.updateApplicationStatus(application_id, 'Rejected');
      }
}
